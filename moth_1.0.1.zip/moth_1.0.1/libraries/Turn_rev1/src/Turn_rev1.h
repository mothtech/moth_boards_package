/*
	Turn.h - Library for Moth Turn human interface device running on SAM3X8C microcontroller.
	Created by Midimods LLC, 8 October 2015.
	
	Contributions by 	
		Phil Manofsky
		Doug Manofsky
		Matthew Sherwood
*/

#ifndef TURN_REV1_H
#define TURN_REV1_H

#include "Arduino.h"
#include "TurnMidi.h"

#if ARDUINO < 10606
#error Turn requires Arduino IDE 1.6.6 or greater. Please update your IDE.
#endif

//Pin Definitions for Turn Board (and other device definitions)

//LED Driver Pins
#define GSCLK_PIN       	PIO_PB25B_TIOA0
#define LED_POWER_PIN   	PIO_PB18
#define XERR_PIN        	PIO_PA21
#define XERR_RGB_PIN    	PIO_PB6
#define LED_LATCH_PIN   	PIO_PB5

#define OEN_PINS			PIO_PB0 | PIO_PB1 | PIO_PB2 | PIO_PB4

//Button Pins
#define BUTTON1_PIN			PIO_PB15
#define BUTTON2_PIN			PIO_PB16
#define BUTTON3_PIN			PIO_PA16
#define BUTTON4_PIN			PIO_PA24

//SPI pins
#define MISO_PIN        	PIO_PA25
#define MOSI_PIN			PIO_PA26
#define SPI_CLK_PIN			PIO_PA27

//TWI pins and constants
#define MUX_RESET_PIN				PIO_PB17
#define TWI_CLK_PIN					PIO_PB13
#define TWI_DATA_PIN				PIO_PB12
#define MUX0_ADR					0x70		//i2c address for first multiplexer
#define MUX1_ADR					0x71		// "     "     "  second     " 
#define ENCDR_ADR					0x36		//i2c address for all AS5600 encoder ICs
#define ANG_MSB_IADR				0x0C		//internal register address for Raw Angle (bits 8:11)
#define ANG_LSB_IADR				0x0D		//internal register address for Raw Angle (bits 0:7)
#define MUX_CH_SELECT(value)		value + 0x08		//data byte sent to MUX0/1 to select Channel #value
#define MUX_CH_SELECT_NONE			0x00		//data byte sent to MUX0/1 to deselect ALL channels
#define TWI_CLK_FREQ				100000		//TWI clock set to 100KHz

//Timer Counter Constants - necessary for the LED drivers to work properly
#define MCLK_FREQ 				84000000		//Master Clock frequency is 84MHz
#define TC_WAVEFORM_DIVISOR 	2 				//because we are using Timer Clock Source 1 (Master Clock/2)
#define TC_WAVEFORM_FREQUENCY 	245760    		//Greyscale Clock Frequency for LED drivers (4096 * 60Hz)
#define GSCLK_CYCLE_LENGTH 		4096			//used for TC1 channel 0 compare value to toggle OEN lines every single greyscale counter cycle
#define TC0_RC0					MCLK_FREQ/TC_WAVEFORM_DIVISOR/TC_WAVEFORM_FREQUENCY
#define TC0_RA0					TC0_RC0/2
#define TC0_RC1					MCLK_FREQ/TC_WAVEFORM_DIVISOR/60

//Button RGB Led Color Definitions

typedef struct {

	uint16_t red;
	uint16_t grn;
	uint16_t blu;

} buttonColor;

// buttonColor mintColor = {0x04DF, 0x0E95, 0x01EB};
// buttonColor peachColor = {0x0F73, 0x05F4, 0x024C};
// buttonColor lilacColor = {0x0E85, 0x04BD, 0x0B88};
// buttonColor aquaColor = {0x0647, 0x0B1B, 0x061A};

const int CENTERS[4] = {120,420,720,1020}; 
const int gridWidth = 1140, gridHeight = 840;
const int xGridCenter = 570, yGridCenter = 420;

class Turn 
{
	public:

		/* Main System Routines */
		Turn();
		void systemInit();
		void readAllKnobs();
		uint16_t getKnobPosition(uint16_t knobNum);
		void resetMuxes();
		void setLedBrightness(uint16_t knobNum, uint16_t ledNum, uint16_t ledBrightness);
		void setButtonColor(uint8_t buttonNum, buttonColor newColor);
		void setAllButtonColors(buttonColor newColor);
		void pushLedData();
		void setAllLedsTo(uint16_t ledBrightness);
		void resetLedValues();
		void resetKnobLeds();
		uint8_t getButtonState(uint16_t buttonNumber);
		uint16_t ledBrightnessValues[13][16];
		uint16_t knobPositionValues[12];

		/* Led Grid Drawing Function/Variables */
		double xLEDloc[12][16], yLEDloc[12][16];		
		
		void mapLedGrid();
		void translateLedGrid(double xTranslation, double yTranslation);
		void rotateLedGrid(double radians);

		void drawCircle(double xLoc, double yLoc, double radius, uint16_t brightness);
		void drawEmptyCircle (double xLoc, double yLoc, double innerRadius, double outerRadius, uint16_t brightness);
		void drawRect (double xLoc, double yLoc, double width, double height, uint16_t brightness);
		void drawEmptyRect (double xLoc, double yLoc, double innerWidth, double innerHeight, double outerWidth, double outerHeight, uint16_t brightness);
		void drawArc (int xLoc, int yLoc, int radius, double startAngle, double stopAngle, int thickness, uint16_t brightness);

		/* MIDI functionality*/
		void midiCC(uint8_t channel, uint8_t controlNum, uint8_t controlValue);
		void midiFineCC(uint8_t channel, uint8_t controlNum, uint8_t controlValueMSB, uint8_t controlValueLSB);
		void midiNoteOn(uint8_t channel, uint8_t noteNum, uint8_t velocity);
		void midiNoteOff(uint8_t channel, uint8_t noteNum, uint8_t velocity);
		void midiFlush();

	private:

		void InitSPI();
		void InitPIO();
		void InitTC();
		void InitTWI();
		
};

extern Turn turn; //create Turn instance of Turn class

#endif /* TURN_REV1_H */



