#include "Arduino.h"
#include "Turn_rev4.h"
#include "TurnMidi.h"

Turn::Turn() {/*no constructer needed*/}

//turns all the relevant SAM3X8C peripherals ON
void Turn::systemInit() {
	InitPIO(); 		//configures all pins on the board to be controlled by the correct peripherals, sets input/output, etc 
	InitTC(); 		//configures Timer Counter to produce 4096*60Hz Clock signal on TIOA0 for LED Driver Greyscale Clock and toggle OEN lines at 60Hz	
	InitSPI();		//configures SPI peripheral to send data to LED drivers
	InitTWI();		//configures TWI to read/write to Encoder ICs
	resetLedValues();
	pushLedData();

	//enable user reset by configuring Reset Controller
	//REG_RSTC_MR |= RSTC_MR_URSTEN;
	
}

//configures Input/Output for all pins on the SAM3X8C used by Turn
void Turn::InitPIO() {

	//PMC turns on clock for PIOA and PIOB
	REG_PMC_PCER0 |= (1 << ID_PIOA) | (1 << ID_PIOB);

	//PIO initialization for GSCLK

		//disable PIO control of GSCLK_PIN and OEN_PIN (enable's peripheral control of pin, aka TC0)
		REG_PIOA_PDR |= OEN_PIN;
		REG_PIOB_PDR |= GSCLK_PIN;
		//AB peripheral select register (each pin has two peripherals it can interface with. PB25's "B" periph is TIOA0. 0 bit means use A periph, 1 bit means use B periph) 
		REG_PIOA_ABSR &= ~OEN_PIN;
		REG_PIOB_ABSR |= GSCLK_PIN | OEN_PIN;

	//PIO initialization for LED lines

		//enable PIO control on TEST_LED, LED_POWER, OEN, XERR, and LATCH pins,
		REG_PIOA_PER |=  TEST_LED_PIN | XERR_PIN;
		REG_PIOB_PER |=  LED_POWER_PIN
		| XERR_RGB_PIN 
		| LED_LATCH_PIN
		;

		//enable output mode on LED Power, LD, and TEST_LED pins
		REG_PIOA_OER |= TEST_LED_PIN;
		REG_PIOB_OER |= LED_POWER_PIN | LED_LATCH_PIN;

		//enable input on XERR pins (output disable register --> enables as input)
		REG_PIOA_ODR |= XERR_PIN;
		REG_PIOB_ODR |= XERR_RGB_PIN;

		//disable pull up resistors on LED Power, LD, and TEST_LED outputs
		REG_PIOA_PUDR |= TEST_LED_PIN;
		REG_PIOB_PUDR |= LED_POWER_PIN | LED_LATCH_PIN;

		//power up LEDs and set LD pin to high (set output data register on PB18, PB5)
		REG_PIOB_SODR = LED_POWER_PIN;

	//PIO initialization for SPI lines (MISO,MOSI,SCLK)

		REG_PIOA_PDR |= MISO_PIN;		//MISO disable PIO control (enable SPI control)
		REG_PIOA_ODR |= MISO_PIN;    	//config MISO as Input
		REG_PIOA_ABSR &= ~MISO_PIN; 	//Peripheral A

		REG_PIOA_PDR |= MOSI_PIN;    	//MOSI disable PIO control (enable SPI control)
		REG_PIOA_OER |= MOSI_PIN;    	//MOSI config as Output
		REG_PIOA_ABSR &= ~MOSI_PIN; 	//Peripheral A

		REG_PIOA_PDR |= SPI_CLK_PIN;   	//SPCK disable PIO control (enable SPI control)
		REG_PIOA_OER |= SPI_CLK_PIN;   	//SPCK  as Output
		REG_PIOA_ABSR &= ~SPI_CLK_PIN; 	//Peripheral A

	//PIO config for button inputs

		REG_PIOB_PER |= BUTTON1_PIN | BUTTON2_PIN;
		REG_PIOA_PER |= BUTTON3_PIN | BUTTON4_PIN;

		REG_PIOB_ODR |= BUTTON1_PIN | BUTTON2_PIN;
		REG_PIOA_ODR |= BUTTON3_PIN | BUTTON4_PIN;

		REG_PIOB_PUDR |= BUTTON1_PIN | BUTTON2_PIN;
		REG_PIOA_PUDR |= BUTTON3_PIN | BUTTON4_PIN;

	//PIO initilization for TWI lines

		//config multiplexer reset pin (PROOFREAD)
		REG_PIOB_PER |= MUX_RESET_PIN;
		REG_PIOB_OER |= MUX_RESET_PIN;
		REG_PIOB_PUDR |= MUX_RESET_PIN;
		REG_PIOB_SODR |= MUX_RESET_PIN;

		REG_PIOB_PDR |= TWI_CLK_PIN | TWI_DATA_PIN;
		REG_PIOB_OER |= TWI_CLK_PIN | TWI_DATA_PIN;
		REG_PIOB_PUDR |= TWI_CLK_PIN | TWI_DATA_PIN;
		REG_PIOB_ABSR &= ~(TWI_CLK_PIN | TWI_DATA_PIN); //Peripheral A (TWI controls pins instead of PIO)

}

//Configures Timer Counter to produce GSCLK on TIOA0 and flip the OEN lines every greyscale counter cycle using TIOB0 with lowest duty cycle
void Turn::InitTC() {
        
	// Configure the PMC to enable the TC0 and TC1 modules.
	REG_PMC_PCER0 |= (1 << ID_TC0) | (1 << ID_TC1);

	// Disable TC clock
	REG_TC0_CCR0 = TC_CCR_CLKDIS;
	REG_TC0_CCR1 = TC_CCR_CLKDIS;
    
    //Disable interrupts on TC0 on channels 0/1
	REG_TC0_IDR0 = 0xFF;
	REG_TC0_IDR1 = 0xFF;

	// Clear status register
	REG_TC0_SR0;
	REG_TC0_SR1;
	
	//configure channel mode for GSCLK pin
	REG_TC0_CMR0 = TC_CMR_TCCLKS_TIMER_CLOCK1           //Counter uses TC Clock Source 1. It is Master Clock / 2
		| TC_CMR_WAVE                                   //enable waveform mode
		| TC_CMR_WAVSEL_UP_RC                           //waveform selection: UP mode with automatic trigger on RC Compare
		| TC_CMR_ACPA_SET                               //when counter hits compare register A, TIOA0 is set HIGH
		| TC_CMR_ACPC_CLEAR                             //when counter hits compare register C, TIOA0 is set LOW
	;

	//configure channel mode for OEN pin
	REG_TC0_CMR1 = TC_CMR_TCCLKS_TIMER_CLOCK1           //Counter uses TC Clock Source 1. It is Master Clock / 2
		| TC_CMR_WAVE                                   //enable waveform mode
		| TC_CMR_WAVSEL_UP_RC                           //waveform selection: UP mode with automatic trigger on RC Compare
		| TC_CMR_ACPC_SET                             //when counter hits compare register A, TIOA0 is set HIGH
		| TC_CMR_ACPA_CLEAR                               //when counter hits compare register C, TIOA0 is set LOW
	;

	//compare registers for GSCLK pin
	REG_TC0_RC0 = TC0_RC0;
	REG_TC0_RA0 = TC0_RA0;

	//compare registers for OEN pin
	REG_TC0_RC1 = TC0_RC1;
	REG_TC0_RA1 = TC0_RA1;

	// enable and restart the counters.
	REG_TC0_CCR0 = TC_CCR_CLKEN;
	REG_TC0_CCR1 = TC_CCR_CLKEN;
	REG_TC0_BCR = TC_BCR_SYNC; // resets/syncs all TC0 counters

}

void Turn::InitSPI() {

	//Enable clock for the SPI0 peripheral
	REG_PMC_PCER0 |= 1 << ID_SPI0;
	
	//Disable the SPI0 peripheral so we can configure it.
	REG_SPI0_CR = SPI_CR_SPIDIS;
	
	//Set as Master, Fixed Peripheral Select, Mode Fault Detection disabled and
	//Peripheral Chip Select is PCS = xxx0 NPCS[3:0] = 1110
	REG_SPI0_MR = SPI_MR_MSTR | SPI_MR_MODFDIS;
	
	//config Chip Select Register
	REG_SPI0_CSR |= SPI_CSR_NCPHA 	//config clock phase
		| 0x00008000					//SPCK baudrate = MCK / SCBR = 84MHz / 128 = 656250Hz
		| SPI_CSR_BITS_12_BIT;					//BITS configs number of bits per transfer
	REG_SPI0_CSR &= ~SPI_CSR_CPOL;	//config clock polarity
	
	//disable SPI interrupts
	REG_SPI0_IDR = 0xFFFFFFFF;

	//Enable the SPI0 unit
	REG_SPI0_CR = SPI_CR_SPIEN;

}

/*
the TWI functions inside of this method can be found
in hardware/arduino/sam/system/libsam/source/twi.c
there is plenty of comments/documentation in that file
*/
void Turn::InitTWI() {

	//enable PMC to power TWI1
	REG_PMC_PCER0 |= 1 << ID_TWI1;

	TWI_ConfigureMaster(TWI1, TWI_CLK_FREQ, MCLK_FREQ);

	resetMuxes();

}

void Turn::resetMuxes() {
	//reset MUXs
	REG_PIOB_CODR |= MUX_RESET_PIN;
	delay(1);
	REG_PIOB_SODR |= MUX_RESET_PIN;
}

void Turn::testLedOn() {
	REG_PIOA_SODR |= TEST_LED_PIN;
}

void Turn::testLedOff() {
	REG_PIOA_CODR |= TEST_LED_PIN;
}

/*
the TWI functions inside of this method can be found
in hardware/arduino/sam/system/libsam/source/twi.c
there is plenty of comments/documentation in that file
*/
void Turn::readAllKnobs() {

	uint16_t knobRawMSB, knobRawLSB;

	//deselect MUX1 channels
	REG_TWI1_MMR = TWI_MMR_DADR(MUX1_ADR) & ~(TWI_MMR_MREAD);
	REG_TWI1_THR = MUX_CH_SELECT_NONE;
	REG_TWI1_CR = TWI_CR_STOP;

	while( !TWI_ByteSent(TWI1) );
	while( !TWI_TransferComplete(TWI1) );

	//cycle through MUX0 channels and read/store knob angle values
	for (uint8_t i = 0; i < 8; i++) {

		REG_TWI1_MMR = TWI_MMR_DADR(MUX0_ADR) & ~(TWI_MMR_MREAD);
		REG_TWI1_THR = MUX_CH_SELECT(i);
		REG_TWI1_CR = TWI_CR_STOP;

		while( !TWI_ByteSent(TWI1) );
		while( !TWI_TransferComplete(TWI1) );

		REG_TWI1_MMR = TWI_MMR_DADR(ENCDR_ADR) | TWI_MMR_MREAD | TWI_MMR_IADRSZ_1_BYTE;
		REG_TWI1_IADR = ANG_MSB_IADR;
		REG_TWI1_CR = TWI_CR_START | TWI_CR_STOP;

		while( !TWI_ByteReceived(TWI1) );

		knobRawMSB = TWI_ReadByte(TWI1);

		while( !TWI_TransferComplete(TWI1) );

		REG_TWI1_MMR = TWI_MMR_DADR(ENCDR_ADR) | TWI_MMR_MREAD | TWI_MMR_IADRSZ_1_BYTE;
		REG_TWI1_IADR = ANG_LSB_IADR;
		REG_TWI1_CR = TWI_CR_START | TWI_CR_STOP;

		while( !TWI_ByteReceived(TWI1) );

		knobRawLSB = TWI_ReadByte(TWI1);

		while( !TWI_TransferComplete(TWI1) );

		knobPositionValues[i] = 0x0FFF & ((knobRawMSB << 8) | knobRawLSB);

	}

	//deselect MUX0 channels
	REG_TWI1_MMR = TWI_MMR_DADR(MUX0_ADR) & ~(TWI_MMR_MREAD);
	REG_TWI1_THR = MUX_CH_SELECT_NONE;
	REG_TWI1_CR = TWI_CR_STOP;

	while( !TWI_ByteSent(TWI1) );
	while( !TWI_TransferComplete(TWI1) );

	//cycle through MUX1 channels and read/store knob angle values
	for (uint8_t i = 0; i < 4; i++) {

		REG_TWI1_MMR = TWI_MMR_DADR(MUX1_ADR) & ~(TWI_MMR_MREAD);
		REG_TWI1_THR = MUX_CH_SELECT(i);
		REG_TWI1_CR = TWI_CR_STOP;

		while( !TWI_ByteSent(TWI1) );
		while( !TWI_TransferComplete(TWI1) );

		REG_TWI1_MMR = TWI_MMR_DADR(ENCDR_ADR) | TWI_MMR_MREAD | TWI_MMR_IADRSZ_1_BYTE;
		REG_TWI1_IADR = ANG_MSB_IADR;
		REG_TWI1_CR = TWI_CR_START | TWI_CR_STOP;

		while( !TWI_ByteReceived(TWI1) );

		knobRawMSB = TWI_ReadByte(TWI1);

		while( !TWI_TransferComplete(TWI1) );

		REG_TWI1_MMR = TWI_MMR_DADR(ENCDR_ADR) | TWI_MMR_MREAD | TWI_MMR_IADRSZ_1_BYTE;
		REG_TWI1_IADR = ANG_LSB_IADR;
		REG_TWI1_CR = TWI_CR_START | TWI_CR_STOP;

		while( !TWI_ByteReceived(TWI1) );

		knobRawLSB = TWI_ReadByte(TWI1);

		while( !TWI_TransferComplete(TWI1) );

		knobPositionValues[i + 8] = 0x0FFF & ((knobRawMSB << 8) | knobRawLSB);

	}

}

uint16_t Turn::getKnobPosition(uint16_t knobNum) {

	return knobPositionValues[knobNum];

}

uint8_t Turn::getButtonState(uint16_t buttonNumber) {

	switch (buttonNumber) {
		case 0:
			return (REG_PIOB_PDSR & BUTTON1_PIN) ? 1 : 0;
			break;
		case 1:
			return (REG_PIOB_PDSR & BUTTON2_PIN) ? 1 : 0;
			break;
		case 2:
			return (REG_PIOA_PDSR & BUTTON3_PIN) ? 1 : 0;
			break;
		case 3:
			return (REG_PIOA_PDSR & BUTTON4_PIN) ? 1 : 0;
			break;
	}

}

//Transfers new data to the LED Drivers using the SPI0 peripheral
void Turn::pushLedData() {

	//latch pin goes low
	REG_PIOB_CODR = LED_LATCH_PIN;

	//send the ledBrightnessValues array in backwards

	for ( int i = 12; i >= 0; i--) {

		for ( int j = 15; j >= 0; j--) {

			//Wait for previous transfer to complete
			while ((REG_SPI0_SR & SPI_SR_TXEMPTY) == 0);

			//load the Transmit Data Register with the value to transmit
			REG_SPI0_TDR = ledBrightnessValues[i][j]; 

			//Wait for data to be transferred to serializer
			while ((REG_SPI0_SR & SPI_SR_TDRE) == 0);

		}

	}
	
	delayMicroseconds(20);

	//latch data
	REG_PIOB_SODR = LED_LATCH_PIN;

}

void Turn::setLedBrightness(uint16_t knobNum, uint16_t ledNum, uint16_t ledBrightness) {
	
	ledBrightnessValues[knobNum][ledNum] = ledBrightness;
	
}

void Turn::setButtonColor(uint8_t buttonNum, buttonColor newColor) {

	switch (buttonNum) {

		case 0:

			ledBrightnessValues[12][0] = newColor.grn;
			ledBrightnessValues[12][1] = newColor.blu;
			ledBrightnessValues[12][2] = newColor.red;
			break;

		case 1:
		
			ledBrightnessValues[12][3] = newColor.grn;
			ledBrightnessValues[12][4] = newColor.blu;
			ledBrightnessValues[12][5] = newColor.red;
			break;
			
		case 2:
		
			ledBrightnessValues[12][6] = newColor.grn;
			ledBrightnessValues[12][7] = newColor.blu;
			ledBrightnessValues[12][8] = newColor.red;
			break;
			
		case 3:
	
			ledBrightnessValues[12][9] = newColor.grn;
			ledBrightnessValues[12][10] = newColor.blu;
			ledBrightnessValues[12][11] = newColor.red;
			break;
			
	}

}

void Turn::setAllButtonColors(buttonColor newColor) {

	ledBrightnessValues[12][0] = newColor.grn;
	ledBrightnessValues[12][1] = newColor.blu;
	ledBrightnessValues[12][2] = newColor.red;
	ledBrightnessValues[12][3] = newColor.grn;
	ledBrightnessValues[12][4] = newColor.blu;
	ledBrightnessValues[12][5] = newColor.red;
	ledBrightnessValues[12][6] = newColor.grn;
	ledBrightnessValues[12][7] = newColor.blu;
	ledBrightnessValues[12][8] = newColor.red;
	ledBrightnessValues[12][9] = newColor.grn;
	ledBrightnessValues[12][10] = newColor.blu;
	ledBrightnessValues[12][11] = newColor.red;



}

void Turn::resetLedValues() {
	
	//fill LED array with zeros
	for (uint8_t i = 0; i < 13; i++) {
		for (uint8_t j = 0; j < 16; j++) {
			ledBrightnessValues[i][j] = 0x0;
		}
	}
	
}

void Turn::resetKnobLeds() {

	for (uint8_t i = 0; i < 12; i++) {
		for (uint8_t j = 0; j < 16; j++) {
			ledBrightnessValues[i][j] = 0x0;
		}
	}

}

void Turn::setAllLedsTo(uint16_t ledBrightness) {

	if (ledBrightness > 0x0FFF) {
		ledBrightness = 0x0FFF;
	}

	//fill LED array with max brightness for all LEDs
	for (uint8_t i = 0; i < 13; i++) {
		for (uint8_t j = 0; j < 16; j++) {
			ledBrightnessValues[i][j] = ledBrightness;
		}
	}

}

/*
// make_Grid maps LEDS to cartesian (1140,840) grid
// (0,0) is the lower left-hand corner of an imaginary box containing just the ring LEDs (no RGBs).
// saves the LED locations in the proper LEDloc
*/
void Turn::mapLedGrid ()
{
    
    for (uint8_t i = 0; i < 12; i++) {

        for (uint8_t j = 0; j < 16; j++) {

            xLEDloc[i][j] = CENTERS[i%4];
            yLEDloc[i][j] = CENTERS[2-(i/4)];

            xLEDloc[i][j] += 120*cos((11*PI/8) - ((PI/8)*j));
            yLEDloc[i][j] += 120*sin((11*PI/8) - ((PI/8)*j));

        }
        
    }
    
}

void Turn::translateLedGrid(double xTranslation, double yTranslation) {

    double newXloc, newYloc;

    for (uint8_t i = 0; i < 12; i++) {
        for (uint8_t j = 0; j < 16; j++) {
            newXloc = xLEDloc[i][j] + xTranslation;
            newYloc = yLEDloc[i][j] + yTranslation;

            xLEDloc[i][j] = newXloc;
            yLEDloc[i][j] = newYloc;
        }
    }

}

void Turn::rotateLedGrid(double radians) {

    double newXloc, newYloc;

    for (uint8_t i = 0; i < 12; i++) {
        for (uint8_t j = 0; j < 16; j++) {
            newXloc = xLEDloc[i][j]*cos(radians) + yLEDloc[i][j]*sin(radians);
            newYloc = -xLEDloc[i][j]*sin(radians) + yLEDloc[i][j]*cos(radians);

            xLEDloc[i][j] = newXloc;
            yLEDloc[i][j] = newYloc;
        }
    }

}

void Turn::drawCircle (double xLoc, double yLoc, double radius, uint16_t brightness) {

    if (radius > 0) {
        
        double xDiff, yDiff, ledDist;

        for (uint8_t i = 0; i < 12; i++) {

            for (uint8_t j = 0; j < 16; j++) {

                xDiff = xLoc - xLEDloc[i][j];
                yDiff = yLoc - yLEDloc[i][j];

                ledDist = (xDiff*xDiff) + (yDiff*yDiff);

                if (ledDist <= radius*radius)
                    ledBrightnessValues[i][j] = brightness;

            }

        }
    
    }

}

void Turn::drawEmptyCircle (double xLoc, double yLoc, double innerRadius, double outerRadius, uint16_t brightness) {

    if (innerRadius > 0 && outerRadius > innerRadius)
    {
        drawCircle(xLoc, yLoc, outerRadius, brightness);
        drawCircle(xLoc, yLoc, innerRadius, 0);
    } else if (innerRadius <= 0 && outerRadius > 0) {
        drawCircle(xLoc, yLoc, outerRadius, brightness);
    }
    

}

void Turn::drawRect (double xLoc, double yLoc, double width, double height, uint16_t brightness) {

    for (uint8_t i = 0; i < 12; i++) {

        for (uint8_t j = 0; j < 16; j++) {

            if (xLEDloc[i][j] <= xLoc + width/2 &&
                xLEDloc[i][j] >= xLoc - width/2 &&
                yLEDloc[i][j] <= yLoc + height/2 &&
                yLEDloc[i][j] >= yLoc - height/2)
                ledBrightnessValues[i][j] = brightness;

        }

    }

}

void Turn::drawEmptyRect (double xLoc, double yLoc, double innerWidth, double innerHeight, double outerWidth, double outerHeight, uint16_t brightness) {
    
    if (innerWidth > 0 && innerHeight > 0 && (outerWidth > innerWidth || outerHeight > innerHeight)) {
    
        drawRect(xLoc, yLoc, outerWidth, outerHeight, brightness);
        drawRect(xLoc, yLoc, innerWidth, innerHeight, 0);
    
    } else if ((innerWidth <= 0 || innerHeight <= 0) && outerWidth > 0 && outerHeight > 0) {
    
        drawRect(xLoc, yLoc, outerWidth, outerHeight, brightness);
    
    }

}

void Turn::drawArc (int xLoc, int yLoc, int radius, double startAngle, double stopAngle, int thickness, uint16_t brightness) {

        startAngle = fmod(startAngle,TWO_PI);
        stopAngle = fmod(stopAngle,TWO_PI);

        if (startAngle < 0)
            startAngle = TWO_PI - startAngle;
        if (stopAngle < 0)
            stopAngle = TWO_PI - stopAngle;

        if (startAngle != stopAngle) {

            double xDiff, yDiff, ledAngle, ledDist, ledMinDist, ledMaxDist, quadrantAngle;
            
            for (uint8_t i = 0; i < 12; i++) {
            
                for (uint8_t j = 0; j < 16; j++) {
                    
                    xDiff = xLEDloc[i][j] - xLoc;
                    yDiff = yLEDloc[i][j] - yLoc;

                    ledDist = sqrt(xDiff*xDiff + yDiff*yDiff);

                    ledMinDist = radius - thickness/2;
                    ledMaxDist = radius + thickness/2;

                    quadrantAngle = asinf(abs(yDiff)/ledDist);

                    if (xDiff >= 0) {

                        if (yDiff > 0)
                            ledAngle = quadrantAngle;
                        else
                            ledAngle = TWO_PI - quadrantAngle;
                    
                    } else if (xDiff < 0) {
                    
                        if (yDiff > 0)
                            ledAngle = PI - quadrantAngle;
                        else if (yDiff < 0)
                            ledAngle = PI + quadrantAngle;
                    
                    } 

                    if (startAngle < stopAngle) {

                        if (startAngle <= ledAngle && stopAngle >= ledAngle) {

                            if (ledMinDist <= ledDist && ledMaxDist >= ledDist) {
                                ledBrightnessValues[i][j] = brightness;
                            }

                        }

                    } else {

                        if (ledAngle <= stopAngle || ledAngle >= startAngle)  {
                            
                            if (ledMinDist <= ledDist && ledMaxDist >= ledDist) {
                                ledBrightnessValues[i][j] = brightness;
                            }

                        }

                    }

                }

            }

        }
    
    

}

void Turn::midiCC(uint8_t channel, uint8_t controlNum, uint8_t controlValue)
{
	midiEventPacket_t event = {0x0B, 0xB0 | channel, controlNum, controlValue};
	MidiUSB.sendMIDI(event);
}

void Turn::midiFineCC(uint8_t channel, uint8_t controlNum, uint8_t controlValueMSB, uint8_t controlValueLSB)
{
	midiEventPacket_t eventMSB = {0x0B, 0xB0 | channel, controlNum, controlValueMSB};
	midiEventPacket_t eventLSB = {0x0B, 0xB0 | channel, controlNum + 32, controlValueLSB};
	MidiUSB.send14bit(eventMSB, eventLSB);
}

void Turn::midiNoteOn(uint8_t channel, uint8_t noteNum, uint8_t velocity)
{
	midiEventPacket_t noteOn = {0x09, 0x90 | channel, noteNum, velocity};
	MidiUSB.sendMIDI(noteOn);
}

void Turn::midiNoteOff(uint8_t channel, uint8_t noteNum, uint8_t velocity) 
{
	midiEventPacket_t noteOff = {0x08, 0x80 | channel, noteNum, velocity};
	MidiUSB.sendMIDI(noteOff);
}

void Turn::midiFlush() {
	MidiUSB.flush();
}

Turn turn;